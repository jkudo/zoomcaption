﻿using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.CognitiveServices.Speech;

namespace Speech.Recognition
{

    class Program
    {

        static async Task Main()
        {
            Console.WriteLine("API Token");

            Console.SetIn(new StreamReader(Console.OpenStandardInput(8192)));
            string apitoken = Console.ReadLine();

            Console.WriteLine("\nSecurity Key");
            string securitykey = Console.ReadLine();

            Console.WriteLine("\nregion (ex:japaneast)");
            string region = Console.ReadLine();

            Console.WriteLine("\nLanguage (ex:ja-JP)");
            string splang = Console.ReadLine();

            await RecognizeSpeechAsync(apitoken, securitykey, region, splang);

            Console.WriteLine("Please press any key to continue...");
            Console.ReadLine();
        }

        static async Task RecognizeSpeechAsync(string apitoken, string securitykey, string region, string splang)
        {

            SpeechConfig speechConfig = SpeechConfig.FromSubscription(securitykey, region);
            speechConfig.SpeechRecognitionLanguage = splang;
            speechConfig.EnableDictation();

            using var recognizer = new SpeechRecognizer(speechConfig);

            var stopRecognition = new TaskCompletionSource<int>();

            recognizer.Recognizing += (s, e) =>
            {
                Console.WriteLine($"RECOGNIZING: Text={e.Result.Text}");
            };
            var seq = 0;
            recognizer.Recognized += async (s, e) =>
            {

                var zoombody = "";
                if (e.Result.Reason == ResultReason.RecognizedSpeech)
                {
                    Console.WriteLine($"RECOGNIZED: Text={e.Result.Text}");
                    zoombody = e.Result.Text;
                }
                else if (e.Result.Reason == ResultReason.NoMatch)

                {
                    Console.WriteLine($"NOMATCH: Speech could not be recognized.");
                }
                var content = new StringContent(zoombody, Encoding.UTF8);

                using (var client = new HttpClient())
                {
                    var response = await client.PostAsync(apitoken + "&lang=jp-JP&seq=" + seq, content);
                }
                seq++;
            };

            recognizer.Canceled += (s, e) =>
            {
                Console.WriteLine($"CANCELED: Reason={e.Reason}");

                if (e.Reason == CancellationReason.Error)
                {
                    Console.WriteLine($"CANCELED: ErrorCode={e.ErrorCode}");
                    Console.WriteLine($"CANCELED: ErrorDetails={e.ErrorDetails}");
                    Console.WriteLine($"CANCELED: Did you update the subscription info?");
                }

                stopRecognition.TrySetResult(0);
            };

            recognizer.SessionStopped += (s, e) =>
            {
                Console.WriteLine("\n    Session stopped event.");
                stopRecognition.TrySetResult(0);
            };
            // Starts continuous recognition. Uses StopContinuousRecognitionAsync() to stop recognition.
            await recognizer.StartContinuousRecognitionAsync();

            // Waits for completion. Use Task.WaitAny to keep the task rooted.
            Task.WaitAny(new[] { stopRecognition.Task });

            // Stops recognition.
            await recognizer.StopContinuousRecognitionAsync();
        }
    }
}